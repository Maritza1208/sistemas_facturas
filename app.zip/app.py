from flask import Flask, request, render_template, redirect, url_for, session, jsonify, send_file
import os
import json
import pandas as pd
import io
import base64
import xml.etree.ElementTree as ET
import requests
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from lxml import etree
from docx import Document
import requests
import urllib3
import re
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# ========== Configuración ==========
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

HISTORIAL_PATH = os.path.join(UPLOAD_FOLDER, "corregidas.json")
if not os.path.exists(HISTORIAL_PATH):
    with open(HISTORIAL_PATH, 'w', encoding='utf-8') as f:
        json.dump([], f)

API_LOGIN_URL = "https://172.17.100.104:9443/api/Auth/LoginSISPRO"
API_CARGA_JSON_URL = "https://172.17.100.104:9443/api/PaquetesFevRips/CargarFevRips"
API_CREDENCIALES = {
    "persona": {
        "identificacion": {
            "tipo": "CC",
            "numero": "1085301187"
        }
    },
    "clave": "HilaSistemas2024*",
    "nit": "891200240"
}

# ========== Funciones ==========

def limpiar_archivos_sin_cuv(upload_folder):
    archivos = os.listdir(upload_folder)
   
    facturas_con_cuv = set()

    # Encontrar facturas corregidas (tienen archivo _CUV_CORREGIDO.json)
    for archivo in archivos:
        if archivo.endswith("_CUV_CORREGIDO.json"):
            num_factura = archivo.split("_")[0]
            facturas_con_cuv.add(num_factura)

    # Construir lista de archivos a conservar (los de las facturas corregidas)
    archivos_a_conservar = set()
    for factura in facturas_con_cuv:
        for archivo in archivos:
            if archivo.startswith(factura + "_"):
                archivos_a_conservar.add(archivo)

    # Siempre conservar corregidas.json
    archivos_a_conservar.add("corregidas.json")

    # Eliminar todo archivo que NO esté en la lista para conservar
    for archivo in archivos:
        if archivo not in archivos_a_conservar:
            ruta_completa = os.path.join(upload_folder, archivo)
            if os.path.isfile(ruta_completa):
                os.remove(ruta_completa)
                print(f"🗑️ Archivo eliminado: {archivo}")

def limpiar_num_factura(num):
    """Elimina todo lo que no sea número del código de factura."""
    return re.sub(r"[^0-9]", "", num)


def buscar_attdoc(num_factura_limpio, carpeta_uploads):
    for archivo in os.listdir(carpeta_uploads):
        if archivo.endswith("_2_AttDoc.xml") and num_factura_limpio in archivo:
            return os.path.join(carpeta_uploads, archivo)
    return None


def corregir_json_valido(ruta_json_original, ruta_salida, uploads_path, num_factura):
    try:
        with open(ruta_json_original, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Ruta esperada del archivo AttDoc.xml
        ruta_attdoc = os.path.join(uploads_path, f"{num_factura}_2_AttDoc.xml")

        if not os.path.exists(ruta_attdoc):
            print(f"❌ No se encontró el archivo AttDoc: {ruta_attdoc}")
            return False

        # Leer el XML en binario y codificar a Base64
        with open(ruta_attdoc, "rb") as archivo_xml:
            contenido_xml = archivo_xml.read()
            contenido_base64 = base64.b64encode(contenido_xml).decode("utf-8")

        # Reemplazar el campo xmlFevFile
        data["xmlFevFile"] = contenido_base64

        # Guardar el JSON corregido
        with open(ruta_salida, "w", encoding="utf-8") as fout:
            json.dump(data, fout, indent=2, ensure_ascii=False)

        print(f"✅ JSON corregido guardado: {ruta_salida}")
        return True

    except Exception as e:
        print(f"❌ Error al corregir JSON para {num_factura}: {e}")
        return False

def validar_json_para_envio(json_data, factura_num):
    errores = []

    if "rips" not in json_data:
        errores.append("Falta el campo 'rips'.")
    else:
        rips = json_data["rips"]
        if "numFactura" not in rips:
            errores.append("Falta 'numFactura'.")
        if "usuarios" not in rips or not rips["usuarios"]:
            errores.append("'usuarios' vacío o inexistente.")

    if not json_data.get("xmlFevFile"):
        errores.append("Falta 'xmlFevFile' o está vacío.")

    if errores:
        print(f"❌ Errores en el JSON de la factura {factura_num}:")
        for error in errores:
            print(f"   - {error}")
        return False

    print(f"✅ JSON de factura {factura_num} está listo para enviar.")
    return True

def verificar_xml_base64_para_todas_las_facturas():
    corregidos = [f for f in os.listdir(UPLOAD_FOLDER) if f.endswith("_CORREGIDO.json")]

    for json_file in corregidos:
        json_path = os.path.join(UPLOAD_FOLDER, json_file)

        try:
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            num_factura = data.get("rips", {}).get("numFactura", "Sin número")
            xml_base64 = data.get("xmlFevFile", "")

            if not xml_base64:
                print(f"⚠️ Factura {num_factura}: No tiene XML codificado en Base64.")
                continue

            xml_decoded = base64.b64decode(xml_base64).decode("utf-8")
            print(f"\n🔍 XML decodificado para factura {num_factura}:")
            print(xml_decoded)
            print("-" * 80)

        except Exception as e:
            print(f"❌ Error procesando {json_file}: {e}")

def cargar_historial():
    try:
        with open(HISTORIAL_PATH, 'r', encoding='utf-8') as f:
            historial = json.load(f)
            if not isinstance(historial, list):
                return []
            return historial
    except Exception:
        return []

def guardar_historial(historial):
    with open(HISTORIAL_PATH, 'w', encoding='utf-8') as f:
        json.dump(historial, f, indent=4, ensure_ascii=False)

def enviar_jsons_corregidos():
    historial_corregidas = cargar_historial()
    corregidos = [f for f in os.listdir(UPLOAD_FOLDER) if f.endswith('_CORREGIDO.json')]
    print(f"🔎 Facturas corregidas encontradas: {corregidos}")

    for json_file in corregidos:
        num_factura = json_file.split("_")[0]
        if num_factura in historial_corregidas:
            print(f"⏭️ Factura {num_factura} ya enviada, saltando...")
            continue

        json_path = os.path.join(UPLOAD_FOLDER, json_file)
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            if not validar_json_para_envio(data, data.get('rips', {}).get('numFactura', 'Sin número')):
                continue

            print(f"📡 Enviando {json_file} al Ministerio...")
            response = requests.post(API_CARGA_JSON_URL, json=data, verify=False)

            if response.status_code == 200:
                respuesta = response.json()
                if respuesta.get('ResultState'):
                    print(f"✅ {json_file}: CUV generado correctamente: {respuesta.get('CodigoUnicoValidacion')}")
                    # Agregar al historial la factura ya enviada
                    historial_corregidas.append(num_factura)
                    guardar_historial(historial_corregidas)
                else:
                    motivo = respuesta.get('ResultadosValidacion', [{}])[0].get('Descripcion', 'Desconocido')
                    print(f"❌ {json_file}: Ministerio rechazó. Motivo: {motivo}")
            else:
                print(f"❌ {json_file}: Error HTTP {response.status_code}")

        except Exception as e:
            print(f"⚠️ Error procesando {json_file}: {e}")

# ========== Inicializar Flask App ==========

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Cargar historial corregidas
with open(HISTORIAL_PATH, 'r', encoding='utf-8') as f:
    historial_corregidas = json.load(f)

        
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        excel = request.files.get("excel")
        carpeta_archivos = request.files.getlist("carpeta")

        if not excel or not carpeta_archivos:
            return render_template("index.html", mensaje="⚠️ Debes subir el archivo Excel y los archivos de la carpeta.")
            
        UPLOAD_FOLDER = "uploads"
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Esto crea la carpeta si no existe

        excel_path = os.path.join(UPLOAD_FOLDER, excel.filename)
        excel.save(excel_path)

        try:
            df = pd.read_excel(excel_path)
            columna_detectada = df.columns[0]
            facturas_excel = df[columna_detectada].astype(str).tolist()
        except Exception as e:
            return render_template("index.html", mensaje=f"❌ Error al leer el Excel: {e}")

        archivo_dict = {}
        for archivo in carpeta_archivos:
            nombre = os.path.basename(archivo.filename)
            ruta = os.path.join(UPLOAD_FOLDER, nombre)
            archivo.save(ruta)
            archivo_dict[nombre] = ruta

        facturas_con_error_xml = []
        facturas_con_cuv_valido = []
        facturas_con_otros_errores = []

        todas_facturas = set(facturas_excel)
        for archivo in archivo_dict:
            if archivo.endswith("_2.json") and not "CUV_CORREGIDO" in archivo:
                num = archivo.split("_")[0]
                todas_facturas.add(num)

        for factura in todas_facturas:
            nombre_error = f"{factura}_2_Error.json"
            ruta_error = archivo_dict.get(nombre_error)

            descripcion = ""
            observacion = ""
            tiene_error_xml = False
            tiene_otro_error = False
            cuv_valido = False
            ya_corregida_previamente = factura in historial_corregidas

            archivo_existe = ruta_error and os.path.exists(ruta_error)

            if ya_corregida_previamente:
                cuv_valido = True
                descripcion = "CUV generado correctamente (registro previo)"
                observacion = historial_corregidas[factura]['observacion']
            elif archivo_existe:
                try:
                    with open(ruta_error, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        result_state = data.get("ResultState", False)
                        resultados = data.get("ResultadosValidacion", [])

                        tiene_rechazo = any(r.get("Clase") == "RECHAZADO" for r in resultados)

                        if result_state and not tiene_rechazo:
                            cuv_valido = True
                            descripcion = "CUV generado correctamente"
                            observacion = "Validación exitosa"
                        else:
                            for resultado in resultados:
                                if resultado.get("Clase") == "RECHAZADO":
                                    descripcion = resultado.get("Descripcion", "")
                                    observacion = resultado.get("Observaciones", "")
                                    if resultado.get("Codigo") == "FEV001" and "[AttachedDocument]" in descripcion:
                                        tiene_error_xml = True
                                    else:
                                        tiene_otro_error = True
                                    break
                except Exception as e:
                    print(f"❌ Error leyendo {ruta_error}: {e}")
            else:
                descripcion = "No se encontró archivo .json"
                observacion = "No aplica"
                tiene_otro_error = True

            resultado = {
                "factura": factura,
                "descripcion": descripcion or "No se encontró clase RECHAZADO",
                "observacion": observacion or "No aplica"
            }

            if cuv_valido:
                facturas_con_cuv_valido.append(resultado)
            elif tiene_error_xml:
                facturas_con_error_xml.append(resultado)
            elif tiene_otro_error:
                facturas_con_otros_errores.append(resultado)

        session['columna_detectada'] = columna_detectada
        session['facturas_con_error'] = facturas_con_error_xml
        session['facturas_con_cuv_corregido'] = facturas_con_cuv_valido
        session['facturas_con_otros_errores'] = facturas_con_otros_errores
        session['archivos_guardados'] = archivo_dict

        return redirect(url_for("resultados"))

    return render_template("index.html")

@app.route("/resultado")
def resultados():
    return render_template("resultados.html",
                           columna_detectada=session.get("columna_detectada", ""),
                           facturas_con_error=session.get("facturas_con_error", []),
                           facturas_con_cuv_corregido=session.get("facturas_con_cuv_corregido", []),
                           facturas_con_otros_errores=session.get("facturas_con_otros_errores", []))


@app.route("/vista_excel")
def vista_excel():
    facturas = []

    corregidas = set(historial_corregidas.keys()) | set(session.get("facturas_recien_corregidas", []))

    for f in session.get("facturas_con_error", []):
        factura = f["factura"]
        estado = "Corregida" if factura in corregidas else "No corregida"
        descripcion = "Error XML corregido" if estado == "Corregida" else f["descripcion"]
        facturas.append({"factura": factura, "estado": estado, "descripcion": descripcion})

    for f in session.get("facturas_con_cuv_corregido", []):
        facturas.append({
            "factura": f["factura"],
            "estado": "Válida",
            "descripcion": "CUV generado correctamente"
        })

    for f in session.get("facturas_con_otros_errores", []):
        facturas.append({
            "factura": f["factura"],
            "estado": "Inválida",
            "descripcion": "Otro tipo de error"
        })

    return render_template("vista_excel.html", facturas=facturas)

@app.route("/descargar_excel_actualizado", methods=["POST"])
def descargar_excel_actualizado():
    data = []

    corregidas = set(historial_corregidas.keys()) | set(session.get("facturas_recien_corregidas", []))

    for f in session.get("facturas_con_error", []):
        factura = f["factura"]
        estado = "Corregida" if factura in corregidas else "No corregida"
        descripcion = "Error XML corregido" if estado == "Corregida" else f["descripcion"]
        data.append({
            "Factura": factura,
            "Estado": estado,
            "Descripción": descripcion
        })

    for f in session.get("facturas_con_cuv_corregido", []):
        data.append({
            "Factura": f["factura"],
            "Estado": "Válida",
            "Descripción": "CUV generado correctamente"
        })

    for f in session.get("facturas_con_otros_errores", []):
        data.append({
            "Factura": f["factura"],
            "Estado": "Inválida",
            "Descripción": "Otro tipo de error"
        })

    df = pd.DataFrame(data)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False, sheet_name='Facturas')
    output.seek(0)

    return send_file(output,
                     download_name="facturas_actualizadas.xlsx",
                     as_attachment=True,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/ver_reportes")
def ver_reportes():
    import os, json
    from datetime import datetime

    ruta_archivo = "uploads/corregidas.json"

    # 1. Cargar datos desde el archivo JSON
    if os.path.exists(ruta_archivo):
        with open(ruta_archivo, "r") as f:
            historial_corregidas = json.load(f)
    else:
        historial_corregidas = {}

    corregidas = []

    # 2. Recorrer lo que está en el JSON
    for factura_id, info in historial_corregidas.items():
        corregidas.append({
            "factura": factura_id,
            "descripcion": "Error XML corregido",
            "observacion": info.get("observacion", "No aplica"),
            "fecha": info.get("fecha", "Fecha no registrada")
        })

    # 3. Enviar los datos al HTML
    return render_template("reportes.html", 
                           fecha=datetime.now().strftime("%Y-%m-%d %H:%M"),
                           total=len(corregidas),
                           facturas=corregidas)



# ✅ REPORTE EN PDF
@app.route("/descargar_pdf")
def descargar_pdf():
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 50

    # Título
    p.setFont("Helvetica-Bold", 16)
    p.drawCentredString(width / 2, y, "📄 Reporte de Facturas Corregidas por Error XML")
    y -= 30

    # Fecha
    p.setFont("Helvetica", 12)
    p.drawString(50, y, f"Fecha de generación: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    y -= 30

    # Línea
    p.setStrokeColorRGB(0, 0, 0)
    p.line(50, y, width - 50, y)
    y -= 20

    corregidas = []
    for f in session.get("facturas_con_error", []):
        factura = f["factura"]
        path = os.path.join(UPLOAD_FOLDER, f"{factura}_2_CUV_CORREGIDO.json")
        if os.path.exists(path):
            corregidas.append(f)

    if not corregidas:
        p.drawString(50, y, "❌ No se encontraron facturas corregidas.")
    else:
        # Tabla encabezado
        p.setFont("Helvetica-Bold", 12)
        p.drawString(50, y, "Factura")
        p.drawString(200, y, "Estado")
        p.drawString(350, y, "Observación")
        y -= 20

        # Filas de datos
        p.setFont("Helvetica", 10)
        for f in corregidas:
            if y < 50:
                p.showPage()
                y = height - 50
            p.drawString(50, y, f["factura"])
            p.drawString(200, y, "Corregida")
            p.drawString(350, y, "Error XML corregido")
            y -= 15

    p.save()
    buffer.seek(0)
    return send_file(buffer, download_name="reporte_facturas_corregidas.pdf", as_attachment=True)


# ✅ REPORTE EN WORD
@app.route("/descargar_word")
def descargar_word():
    doc = Document()
    doc.add_heading("📄 Reporte de Facturas Corregidas por Error XML", level=0)
    doc.add_paragraph(f"Fecha de generación: {datetime.now().strftime('%Y-%m-%d %H:%M')}")

    corregidas = []
    for f in session.get("facturas_con_error", []):
        factura = f["factura"]
        path = os.path.join(UPLOAD_FOLDER, f"{factura}_2_CUV_CORREGIDO.json")
        if os.path.exists(path):
            corregidas.append(f)

    if not corregidas:
        doc.add_paragraph("❌ No se encontraron facturas corregidas.")
    else:
        table = doc.add_table(rows=1, cols=3)
        table.style = 'Light Grid Accent 1'

        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = "Factura"
        hdr_cells[1].text = "Estado"
        hdr_cells[2].text = "Observación"

        for f in corregidas:
            row_cells = table.add_row().cells
            row_cells[0].text = f["factura"]
            row_cells[1].text = "Corregida"
            row_cells[2].text = "Error XML corregido"

    output = io.BytesIO()
    doc.save(output)
    output.seek(0)
    return send_file(output,
                     download_name="reporte_facturas_corregidas.docx",
                     as_attachment=True,
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


# Ruta para procesar las facturas con error en XML
@app.route("/corregir", methods=["POST"])
def corregir_y_enviar():
    try:
        print("=== INICIO CORRECCIÓN AUTOMÁTICA ===")
        archivo_dict = session.get("archivos_guardados", {})
        facturas_con_error = session.get("facturas_con_error", [])
        historial_corregidas = {}
        facturas_cuv = session.get("facturas_con_cuv_corregido", [])

        if not facturas_con_error:
            print("⚠️ No hay facturas con error XML para corregir.")
            return jsonify({"mensaje": "No hay facturas con error XML."}), 400

        # 1. Autenticación
        print("🔐 Autenticando en", API_LOGIN_URL)
        r_login = requests.post(API_LOGIN_URL, json=API_CREDENCIALES, verify=False)
        r_login.raise_for_status()
        token = r_login.json().get("token")
        if not token:
            return jsonify({"mensaje": "No se pudo autenticar con el Ministerio."}), 401

        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

        errores = []
        corregidas = []

        for f in facturas_con_error:
            num = f["factura"]
            print(f"\n--- Procesando factura {num} ---")

            path_json = archivo_dict.get(f"{num}_2.json")
            if not path_json or not os.path.exists(path_json):
                errores.append(f"{num}: JSON original no encontrado.")
                continue

            ruta_salida = os.path.join(UPLOAD_FOLDER, f"{num}_2_CORREGIDO.json")
            num_limpio = limpiar_num_factura(num)

            ok = corregir_json_valido(path_json, ruta_salida, UPLOAD_FOLDER, num_limpio)
            if not ok:
                errores.append(f"{num}: Error al corregir el JSON.")
                continue

            with open(ruta_salida, "r", encoding="utf-8") as fcor:
                json_corregido = json.load(fcor)

            if not validar_json_para_envio(json_corregido, num):
                errores.append(f"{num}: JSON inválido, no se envió.")
                continue

            print(f"📡 Enviando factura {num} corregida...")
            r = requests.post(API_CARGA_JSON_URL, headers=headers, json=json_corregido, verify=False)
            res = r.json()

            # CUV ya existente (RVG02)
            if (not res.get("ResultState") and
                any(item.get("Codigo") == "RVG02" for item in res.get("ResultadosValidacion", []))):
                texto = next(item["Observaciones"]
                             for item in res["ResultadosValidacion"]
                             if item.get("Codigo") == "RVG02")
                import re
                m = re.search(r"CUV\s*([0-9a-f]+)", texto)
                if m:
                    cuv_extraido = m.group(1)
                    nuevo_res = {
                        "ResultState": True,
                        "ProcesoId": res["ProcesoId"],
                        "NumFactura": res["NumFactura"],
                        "CodigoUnicoValidacion": cuv_extraido,
                        "FechaRadicacion": res["FechaRadicacion"],
                        "RutaArchivos": res.get("RutaArchivos"),
                        "ResultadosValidacion": [
                            item for item in res["ResultadosValidacion"]
                            if item.get("Clase") == "NOTIFICACION"
                        ]
                    }
                    cuv_path = os.path.join(UPLOAD_FOLDER, f"{num}_2_CUV_CORREGIDO.json")
                    with open(cuv_path, "w", encoding="utf-8") as f_cuv:
                        json.dump(nuevo_res, f_cuv, indent=2, ensure_ascii=False)
                    historial_corregidas[num] = {
                        "fecha": datetime.now().strftime("%Y-%m-%d %H:%M"),
                        "observacion": cuv_extraido
                    }
                    corregidas.append({"factura": num, "observacion": cuv_extraido})
                    print(f"🔄 {num}: Armado CUV existente y guardado: {cuv_extraido}")

                    # ➕ Mover factura a facturas_con_cuv_corregido
                    facturas_cuv.append({"factura": num, "observacion": cuv_extraido})
                    continue

            # CUV generado nuevo
            if r.status_code == 200 and res.get("ResultState"):
                cuv_path = os.path.join(UPLOAD_FOLDER, f"{num}_2_CUV_CORREGIDO.json")
                with open(cuv_path, "w", encoding="utf-8") as f_cuv:
                    json.dump(res, f_cuv, indent=2, ensure_ascii=False)
                cuv = res.get("CodigoUnicoValidacion", "CUV generado")
                historial_corregidas[num] = {
                    "fecha": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "observacion": cuv
                }
                corregidas.append({"factura": num, "observacion": cuv})
                print(f"✅ CUV generado y guardado para {num}")

                # ➕ Mover factura a facturas_con_cuv_corregido
                facturas_cuv.append({"factura": num, "observacion": cuv})
            else:
                obs = res.get("ResultadosValidacion", [{}])[0].get("Observaciones", "Error desconocido")
                errores.append(f"{num}: {obs}")
                print(f"❌ Ministerio rechazó {num}: {obs}")

        # 🔄 Remover facturas corregidas de la lista original de errores
        facturas_con_error = [
            f for f in facturas_con_error
            if f["factura"] not in [c["factura"] for c in corregidas]
        ]

        session["facturas_con_error"] = facturas_con_error
        session["facturas_con_cuv_corregido"] = facturas_cuv

        # 🔄 También mover a facturas con CUV válido para que aparezcan en esa tabla automáticamente
        facturas_cuv_validas = session.get("facturas_con_cuv_valido", [])
        for factura in facturas_cuv:
            if factura not in facturas_cuv_validas:
                facturas_cuv_validas.append(factura)
        session["facturas_con_cuv_valido"] = facturas_cuv_validas

        guardar_historial(historial_corregidas)

        limpiar_archivos_sin_cuv(UPLOAD_FOLDER)

        print(f"\n=== FIN CORRECCIÓN. Total corregidas: {len(corregidas)}, Errores: {len(errores)} ===")
        return jsonify({
            "mensaje": "Corrección finalizada",
            "corregidas": corregidas,
            "errores": errores
        }), 200

    except Exception as e:
        print(f"❌ ERROR GENERAL: {e}")
        return jsonify({"mensaje": "Error inesperado"}), 500


if __name__ == "__main__":
    app.run(debug=True)